/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;

/**
 *
 * @author estudiante
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int A;
        int B;
        System.out.println("ingrese Valor de A");
        Scanner a= new Scanner (System.in);
    }
    
}
